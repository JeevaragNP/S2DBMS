<?php
    include "connect.php";
    $id = $_GET['id'];
    echo $id;
    $collection->deleteOne(['_id' => new MongoDB\BSON\ObjectID($id)]);
    header("location:view.php");
?>
