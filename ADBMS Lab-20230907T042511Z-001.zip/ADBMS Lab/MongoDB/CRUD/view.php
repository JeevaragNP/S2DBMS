<?php
    include "connect.php";
    $res = $collection->find();
?>

<html>
    <head>
        <title>view page</title>
    </head>
    <body>
        <table border='1'>
            <thead>
                <tr>
                    <th>Full Name</th><th>Email</th><th>Address</th><th>Phone No</th><th>Delete</th><th>Update</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($res as $out){
                ?>
                <tr>
                    <td><?php echo $out["Full Name"]; ?></td>
                    <td><?php echo $out["Email"]; ?></td>
                    <td><?php echo $out["Address"]; ?></td>
                    <td><?php echo $out["Phone Number"]; ?></td>
                    <td><a href="delete.php?id=<?php $res['_id']; ?>">Delete</a><td>
                    <td><a href="update.php?id=<?php $res['_id']; ?>">Update</a><td>
                </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
    </body>
</html>