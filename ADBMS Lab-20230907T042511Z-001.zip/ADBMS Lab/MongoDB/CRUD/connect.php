<?php 
    require'../vendor/autoload.php';
    $con = new MongoDB\Client("mongodb://localhost:27017");
    //echo $con;
    //connect php to mongodb database
    $database = $con->php_crud_mongo;
    echo $database;
    $collection = $database->Jeevs;
    echo "Collection created";
?>