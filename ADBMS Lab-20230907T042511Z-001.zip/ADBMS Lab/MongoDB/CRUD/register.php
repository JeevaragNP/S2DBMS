<?php
    include 'connect.php';
        $name = $_POST['nam'];
        $email = $_POST['mail'];
        $address =$_POST['adrs'];
        $phone_no=$_POST['phno'];
        
        $data = array("Full Name"=>$name,
                        "Email"=>$email,
                        "Address"=>$address,
                        "Phone Number"=>$phone_no);
        $collection->insertOne($data);
        header("location:view.php");
?>