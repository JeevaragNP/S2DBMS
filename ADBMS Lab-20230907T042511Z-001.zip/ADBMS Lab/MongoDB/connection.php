<?php
	require '../vendor/autoload.php';
	
	//connect to mongodb
	$con = new MongoBD\Client("mongodb://localhost:27017");
	
	//select a database
	$db = $con->user;
	echo "Database admin selected";
	$collection = $db->createCollection("sample");
	echo "Collection sample created successfully";
?>